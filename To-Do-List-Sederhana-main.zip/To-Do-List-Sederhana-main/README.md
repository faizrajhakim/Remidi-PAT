# To-Do-List-Sederhana
To Do List Sederhana menggunakan HTML,CSS dan JAVASCRIPT
----
![Capture](https://user-images.githubusercontent.com/121668350/218366260-0ae328cd-23d3-4763-ad5d-7ddc1189cf79.PNG)
----
![s](https://user-images.githubusercontent.com/121668350/218366717-81d25fcd-c800-4173-8444-be24e0d1f52c.PNG)

